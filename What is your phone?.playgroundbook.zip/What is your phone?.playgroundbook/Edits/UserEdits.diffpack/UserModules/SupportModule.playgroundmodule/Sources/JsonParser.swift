import Foundation

public class JsonParser {
    public init() {}
    private func parserJson<TypeDecoder: Decodable>(type: TypeDecoder.Type, data: Data) throws -> TypeDecoder {
        do {
            let decoder = JSONDecoder()
            let data = try decoder.decode(TypeDecoder.self, from: data)
            return data
        } catch {
            throw(error)
        }
    }
}

extension JsonParser {
    public func getElementsArray() -> [ElementModel]? {
        if let path = Bundle.main.path(forResource: "Elements", ofType: "json") {
            do{
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let elementsArray: [ElementModel] = try parserJson(type: [ElementModel].self, data: data)
                return elementsArray
            } catch {
                print(error)
            }
        }
        return nil
    }
    
    public func getSceneModelsArray() -> [SceneDataModel]? {
        if let path = Bundle.main.path(forResource: "ScenesData", ofType: "json") {
            do{
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let sceneModelsArray: [SceneDataModel] = try parserJson(type: [SceneDataModel].self, data: data)
                return sceneModelsArray
            } catch {
                print(error)
            }
        }
        return nil
    }
    
    public func getElementsGroupsArray() -> [ElementsGroupModel]? {
        if let path = Bundle.main.path(forResource: "ElementsGroups", ofType: "json") {
            do{
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let elementsGroupsArray: [ElementsGroupModel] = try parserJson(type: [ElementsGroupModel].self, data: data)
                return elementsGroupsArray
            } catch {
                print(error)
            }
        }
        return nil
    }
}
