import Foundation

public struct SceneDataModel: Decodable {
    public var sceneIndex: Int
    public var sceneName: String
    public var elementsNumbersToFind: [String]
    public var finalElementsArray: [[String]]
    public var finalElementsDescArray: [String]
}
