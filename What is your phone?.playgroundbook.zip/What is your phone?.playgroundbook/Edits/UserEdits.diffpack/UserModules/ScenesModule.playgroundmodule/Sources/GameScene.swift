import SpriteKit
import SupportModule

public class GameScene: SKScene {
    private var sceneFinishedClosure: (() -> ())?
    private var model: SceneDataModel
    private var elementsArray = JsonParser().getElementsArray()
    private var elementsGroupsArray = JsonParser().getElementsGroupsArray()
    
    private var elementSize = CGSize()
    private var bottomBarNode = SKShapeNode()
    private var selectedNode: SKShapeNode?
    private var currentTouchPos: CGPoint?
    private var detailImageNode = SKSpriteNode()
    
    public init(size: CGSize, model: SceneDataModel, sceneFinishedClosure: (() -> ())?) {
        self.elementSize = CGSize(width: size.width * 0.075, height: size.width * 0.075)
        self.model = model
        self.sceneFinishedClosure = sceneFinishedClosure
        super.init(size: size)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override public func didMove(to view: SKView) {
        scene?.physicsWorld.gravity = CGVector(dx: 0, dy: 0)
        let borderBody = SKPhysicsBody(edgeLoopFrom: self.frame)
        borderBody.friction = 10
        borderBody.density = 100000
        scene?.physicsBody = borderBody
        
        addDetailImage()
        showSceneName()
    }
    
    private func showSceneName() {
        let sceneNameLabel = SKLabelNode(text: self.model.sceneName)
        sceneNameLabel.position = CGPoint(x: 0, y: 60)
        sceneNameLabel.alpha = 0
        sceneNameLabel.fontSize = 110
        sceneNameLabel.verticalAlignmentMode = .center
        addChild(sceneNameLabel)
        
        let scenePartNumberLabel = SKLabelNode(text: "Part \(self.model.sceneIndex)/4")
        scenePartNumberLabel.position.y = sceneNameLabel.position.y - 130
        scenePartNumberLabel.verticalAlignmentMode = .center
        sceneNameLabel.addChild(scenePartNumberLabel)
        
        let sequence = SKAction.sequence([SKAction.wait(forDuration: 0.6),
                                          SKAction.fadeAlpha(to: 1, duration: 0.6),
                                          SKAction.wait(forDuration: 2),
                                          SKAction.fadeAlpha(to: 0, duration: 0.6)])
        
        sceneNameLabel.run(sequence, completion: {
            self.addBottombar(elementsCount: self.model.elementsNumbersToFind.count)
            self.createElements()
            self.addElementsGroups()
        })
    }
    
    private func addElementsGroups() {
        guard let elementsGroupsArray = self.elementsGroupsArray else { return }
        var elementsGroupsWidthSum: CGFloat = 0
        var nodesArray = [SKNode]()
        
        elementsGroupsArray.forEach({
            let colorCircle = SKShapeNode(circleOfRadius: 10)
            colorCircle.fillColor = $0.groupColor
            colorCircle.strokeColor = SKColor.clear
            
            let groupName = SKLabelNode(text: $0.groupName)
            groupName.fontSize = 14
            groupName.verticalAlignmentMode = .center
            groupName.fontName = "HelveticaNeue"
            
            let containerNode = SKShapeNode(rectOf: CGSize(width: colorCircle.frame.size.width + groupName.frame.size.width + CGFloat(5),
                                                           height: 20))
            containerNode.position.y = self.frame.maxY - containerNode.frame.height / 2 - CGFloat(4)
            containerNode.strokeColor = SKColor.clear
            containerNode.alpha = 0
            containerNode.physicsBody = SKPhysicsBody(rectangleOf: containerNode.frame.size)
            containerNode.physicsBody?.isDynamic = false
            
            colorCircle.position.x = containerNode.frame.minX + colorCircle.frame.width / 2
            groupName.position.x = colorCircle.frame.maxX + groupName.frame.width / 2 + CGFloat(5)
            
            containerNode.addChild(colorCircle)
            containerNode.addChild(groupName)
            
            nodesArray.append(containerNode)
            elementsGroupsWidthSum += containerNode.frame.size.width
        })
        
        let xSpacing = (self.size.width - elementsGroupsWidthSum) / CGFloat(elementsGroupsArray.count + 1)
        var lastElementXPos: CGFloat = self.frame.minX + xSpacing
        
        nodesArray.forEach({
            $0.position.x = lastElementXPos + $0.frame.size.width / 2
            self.addChild($0)
            lastElementXPos += $0.frame.size.width + xSpacing
            $0.run(SKAction.fadeAlpha(to: 1, duration: 0.6))
        })
    }
    
    private func addBottombar(elementsCount: Int) {
        let rowsCount = elementsCount > 12 ? 2 : 1
        let xOffset = 20
        let yOffset = 10
        let smallElementSize = elementSize.width * 0.7
        let elementsCountInRow = Int(elementsCount / rowsCount)
        let xOffsetSum = (xOffset * 2) + (elementsCountInRow - 1) * xOffset
        
        let bottomBarSize = CGSize(width: (CGFloat(elementsCountInRow) * smallElementSize) + CGFloat(xOffsetSum),
                                   height: (CGFloat(rowsCount) * smallElementSize + CGFloat((rowsCount + 1) * yOffset) + CGFloat(20)))
        self.bottomBarNode = SKShapeNode(rectOf: bottomBarSize, cornerRadius: 20)
        
        bottomBarNode.position.y = -(self.size.height / 2) - (bottomBarSize.height / 2 + 20)
        bottomBarNode.isUserInteractionEnabled = true
        bottomBarNode.fillColor = SKColor.darkGray
        bottomBarNode.strokeColor = SKColor.clear
        bottomBarNode.physicsBody = SKPhysicsBody(rectangleOf: bottomBarSize)
        bottomBarNode.physicsBody?.restitution = 0
        bottomBarNode.physicsBody?.isDynamic = false
        addChild(bottomBarNode)
        
        for j in 0..<rowsCount {
            let currentYOffset = CGFloat(j) * (smallElementSize + CGFloat(yOffset))
            for i in 0..<Int(elementsCount / rowsCount) {
                let emptyNode = SKShapeNode(rectOf: CGSize(width: smallElementSize, height:  smallElementSize), cornerRadius: 20 * 0.7)
                
                emptyNode.position = CGPoint(x: -bottomBarNode.frame.size.width / 2 + CGFloat(xOffset) + smallElementSize / 2
                    + smallElementSize * CGFloat(i) + CGFloat(xOffset * i),
                                             y: bottomBarNode.frame.size.height / 2 - CGFloat(yOffset) - smallElementSize / 2 - currentYOffset)
                
                emptyNode.fillColor = SKColor.clear
                emptyNode.name = self.model.elementsNumbersToFind[elementsCountInRow * j + i]
                
                if let elementColor = self.elementsArray?.first(where: { $0.number == emptyNode.name })?.color {
                    emptyNode.strokeColor = elementColor
                }
                emptyNode.lineWidth = 2.5
                
                bottomBarNode.addChild(emptyNode)
                
                let numberLabel = SKLabelNode(text: self.model.elementsNumbersToFind[elementsCountInRow * j + i])
                numberLabel.verticalAlignmentMode = .center
                numberLabel.fontSize = 20
                emptyNode.addChild(numberLabel)
            }
        }
        
        bottomBarNode.run(SKAction.move(to: CGPoint(x: 0, y: -(self.size.height / 2) + (bottomBarSize.height / 2 - 20)),
                                        duration: 0.6))
        createGravityField()
    }
    
    private func createElements() {
        guard let elementsArray = self.elementsArray else { return }
        
        for element in elementsArray {
            let elementNode = SKShapeNode(rectOf: elementSize, cornerRadius: 20)
            elementNode.name = element.number
            elementNode.fillColor = element.color
            elementNode.strokeColor = SKColor.clear
            elementNode.alpha = 0
            elementNode.position = CGPoint(x: Int.random(in: -(Int(self.size.width) / 2)..<(Int(self.size.width) / 2 - Int(elementSize.width))),
                                           y: Int.random(in: Int(bottomBarNode.frame.maxY + elementSize.width)..<(Int(self.size.height) / 2 - Int(elementSize.width))))
            
            elementNode.physicsBody = SKPhysicsBody(rectangleOf: elementNode.frame.size)
            elementNode.physicsBody?.allowsRotation = false
            elementNode.physicsBody?.density = 1000
            elementNode.physicsBody?.restitution = 0
            addChild(elementNode)
            
            let symbolLabel = SKLabelNode(text: element.symbol)
            symbolLabel.verticalAlignmentMode = .center
            symbolLabel.fontName = "AppleSDGothicNeo-Bold"
            elementNode.addChild(symbolLabel)
            
            let numberLabel = SKLabelNode(text: element.number)
            numberLabel.verticalAlignmentMode = .center
            numberLabel.position = CGPoint(x: 0 , y: elementNode.frame.size.height / 2 - 16)
            numberLabel.fontName = "AppleSDGothicNeo-SemiBold"
            numberLabel.fontSize = 16
            elementNode.addChild(numberLabel)
            
            let nameLabel = SKLabelNode(text: element.name)
            nameLabel.verticalAlignmentMode = .center
            nameLabel.position = CGPoint(x: 0 , y: -(elementNode.frame.size.height / 2) + 16)
            nameLabel.fontName = "AppleSDGothicNeo-Bold"
            nameLabel.fontSize = 15
            nameLabel.xScale = 0.78
            elementNode.addChild(nameLabel)
            
            let sequence = SKAction.sequence([SKAction.wait(forDuration: 0.6),
                                              SKAction.fadeAlpha(to: 1, duration: 0.6)])
            elementNode.run(sequence)
        }
    }
    
    private func addDetailImage() {
        self.detailImageNode = SKSpriteNode(imageNamed: self.model.sceneName)
        let ratio = self.detailImageNode.size.width / self.detailImageNode.size.height
        self.detailImageNode.size.width = self.size.width * 0.2
        self.detailImageNode.size.height = self.detailImageNode.size.width / ratio
        self.detailImageNode.position = CGPoint(x: 0, y: 60)
        self.detailImageNode.alpha = 0
        self.detailImageNode.run(SKAction.fadeAlpha(to: 0.2, duration: 0.4))
        self.detailImageNode.zPosition = -1
        
        addChild(self.detailImageNode)
    }
    
    private func startBuilding() {
        let usedElementsNodes = self.children.filter({ $0.name != nil && self.model.elementsNumbersToFind.contains($0.name!)})
        usedElementsNodes.forEach({
            $0.run(SKAction.fadeAlpha(to: 0, duration: 0.1))
        })
        
        let unusedElementsNodes = self.children.filter({ $0.name != nil && !self.model.elementsNumbersToFind.contains($0.name!)})
        unusedElementsNodes.forEach({
            $0.run(SKAction.fadeAlpha(to: 0, duration: 0.7))
            $0.run(SKAction.scale(to: 0.5, duration: 0.7))
        })
        
        self.bottomBarNode.run(SKAction.move(by: CGVector(dx: 0, dy: -self.bottomBarNode.frame.size.height), duration: 0.5), completion: {
            self.detailImageNode.run(SKAction.fadeAlpha(to: 1, duration: 0.7))
            
            let moveAction = SKAction.move(to: CGPoint(x: -self.size.width / 2 + self.detailImageNode.frame.width, y: 0), duration: 1)
            moveAction.timingMode = .easeInEaseOut
            self.detailImageNode.run(moveAction, completion: {
                self.showNextElementsInfo()
            })
        })
    }
    
    private func showNextElementsInfo() {
        let labelNode = SKLabelNode()
        
        let attrString = NSMutableAttributedString(string: self.model.finalElementsDescArray[0])
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        let range = NSRange(location: 0, length: self.model.finalElementsDescArray[0].count)
        attrString.addAttribute(NSAttributedString.Key.paragraphStyle, value: paragraphStyle, range: range)
        attrString.addAttributes([NSAttributedString.Key.foregroundColor : UIColor.white,
                                  NSAttributedString.Key.font : UIFont(name: "HelveticaNeue-Thin", size: 30)!], range: range)
        
        labelNode.attributedText = attrString
        labelNode.name = "elementsDescLabel"
        labelNode.position = CGPoint(x: self.size.width / 6, y: 0)
        labelNode.numberOfLines = 0
        labelNode.preferredMaxLayoutWidth = self.size.width / 2
        labelNode.alpha = 0
        self.addChild(labelNode)
        
        labelNode.run(SKAction.fadeAlpha(to: 1, duration: 0.7), completion: {
            self.bottomBarNode.run(SKAction.move(by: CGVector(dx: 0, dy: self.bottomBarNode.frame.size.height), duration: 0.5), completion: {
                
                for i in self.model.finalElementsArray[0].indices {
                    let elementNode = self.bottomBarNode.children.first(where: { $0.name == self.model.finalElementsArray[0][i]})
                    elementNode!.move(toParent: self)
                    let xOffset = CGFloat(self.model.finalElementsArray[0].count - 1) * 20.0
                    let elementsWidth = CGFloat(self.model.finalElementsArray[0].count) * self.elementSize.width + xOffset
                    let elementNodePosition = CGPoint(x: labelNode.position.x - elementsWidth / 2 + self.elementSize.width / 2 + CGFloat(i) * (self.elementSize.width + 20.0), y: labelNode.position.y - 70)
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2 * Double(i)) {
                        elementNode?.run(SKAction.move(to: elementNodePosition, duration: 0.3))
                        elementNode?.run(SKAction.scale(to: 1.0, duration: 0.3))
                    }
                }
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2 * Double(self.model.finalElementsArray[0].count + 2)) {
                    self.bottomBarNode.run(SKAction.move(by: CGVector(dx: 0, dy: -self.bottomBarNode.frame.size.height), duration: 0.5),
                                           completion: {
                                            let buttonNode = SKShapeNode(rectOf: CGSize(width: 300, height: 65), cornerRadius: 16)
                                            buttonNode.position = CGPoint(x: labelNode.position.x, y: -200)
                                            buttonNode.alpha = 0
                                            buttonNode.name = "buildBtn"
                                            buttonNode.run(SKAction.fadeAlpha(to: 1, duration: 0.7))
                                            self.addChild(buttonNode)
                                            
                                            let btnText = SKLabelNode(text: "Apply")
                                            btnText.verticalAlignmentMode = .center
                                            buttonNode.addChild(btnText)
                    })
                }
            })
        })
    }
    
    private func tryAddInBar(node: SKShapeNode) {
        guard let selectedNode = self.selectedNode else { return }
        selectedNode.physicsBody = nil
        let targetNodePosition = CGPoint(x: node.position.x + node.parent!.position.x,
                                         y: node.position.y + node.parent!.position.y)
        selectedNode.run(SKAction.scale(to: 0.7, duration: 0.24))
        selectedNode.run(SKAction.move(to: targetNodePosition, duration: 0.3), completion: {
            node.name = nil
            node.removeAllChildren()
            selectedNode.zPosition = 0
            selectedNode.move(toParent: self.bottomBarNode)
            
            if self.bottomBarNode.children.filter({ $0.name == nil }).count == self.model.elementsNumbersToFind.count {
                self.startBuilding()
            }
        })
        selectedNode.isUserInteractionEnabled = true
    }
    
    private func isNodeInBottomBarZone() -> Bool {
        guard let selectedNode = self.selectedNode else { return false }
        if selectedNode.position.y < bottomBarNode.frame.maxY + elementSize.height {
            if (bottomBarNode.frame.minX - elementSize.width) ... (bottomBarNode.frame.maxX + elementSize.width) ~= selectedNode.position.x {
                return true
            }
        }
        return false
    }
    
    private func createGravityField() {
        let gravityField = SKFieldNode.radialGravityField()
        let regionSize = CGSize(width: bottomBarNode.frame.size.width + elementSize.width * 2,
                                height: (bottomBarNode.frame.size.height + elementSize.height) * 2)
        
        gravityField.region = SKRegion(size: regionSize)
        gravityField.position = CGPoint(x: 0, y: -bottomBarNode.frame.size.height / 2)
        gravityField.strength = -14
        gravityField.name = "botBarGravityField"
        
        self.bottomBarNode.addChild(gravityField)
    }
    
    private func handleTouchEnd(pos: CGPoint?) {
        if let touchedNode = scene?.nodes(at: pos!).first(where: { $0 is SKShapeNode && $0.name == "buildBtn"}) {
            let elementsToGo = self.children.filter({ $0.name != nil && self.model.finalElementsArray[0].contains( $0.name! )})
            
            for i in elementsToGo.indices {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2 * Double(i)) {
                    elementsToGo[i].zPosition = -2
                    elementsToGo[i].run(SKAction.move(to: self.detailImageNode.position, duration: 0.4), completion: {
                        elementsToGo[i].removeFromParent()
                    })
                }
            }
            
            touchedNode.run(SKAction.fadeAlpha(to: 0, duration: 0.5), completion: {
                touchedNode.removeFromParent()
                self.model.finalElementsArray.remove(at: 0)
                self.model.finalElementsDescArray.remove(at: 0)
                if (self.model.finalElementsDescArray.count == 0) {
                    let sequence = SKAction.sequence([SKAction.wait(forDuration: 0.2 * Double(elementsToGo.count)),
                                                      SKAction.fadeAlpha(to: 0, duration: 1)])
                    self.children.first(where: { $0.name == "elementsDescLabel" })?.run(sequence)
                    self.run(sequence, completion: {
                        self.removeAllChildren()
                        self.alpha = 1
                        let sceneFinishedLabel = SKLabelNode(text: "Part \(self.model.sceneIndex) complete!")
                        sceneFinishedLabel.alpha = 0
                        sceneFinishedLabel.fontSize = 80
                        self.addChild(sceneFinishedLabel)
                        sceneFinishedLabel.run(SKAction.sequence([SKAction.fadeAlpha(to: 1, duration: 0.5),
                                                                  SKAction.wait(forDuration: 1),
                                                                  SKAction.fadeAlpha(to: 0, duration: 0.5)]), completion: {
                                                                    self.sceneFinishedClosure?()
                        })
                    })
                    return
                }
                self.showNextElementsInfo()
                self.children.first(where: { $0.name == "elementsDescLabel" })?.removeFromParent()
            })
            return
        }
        
        if isNodeInBottomBarZone() {
            guard let selectedNode = self.selectedNode else { return }
            if let targetNode = self.bottomBarNode.children.first(where: { $0.name == selectedNode.name}) {
                tryAddInBar(node: targetNode as! SKShapeNode)
            } else {
                selectedNode.run(SKAction.scale(to: 1, duration: 0.24))
            }
        }
        
        self.selectedNode = nil
    }
    
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let pos = touches.first?.location(in: self) else { return }
        if selectedNode != nil { return }
        if let touchedNode = scene?.nodes(at: pos).first(where: { $0 is SKShapeNode}) {
            self.selectedNode = touchedNode as? SKShapeNode
            self.selectedNode?.run(SKAction.scale(to: 1.08, duration: 0.15))
            self.currentTouchPos = pos
        }
    }
    
    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let pos = touches.first?.location(in: self) else { return }
        if (pos.x < self.frame.minX || pos.x > self.frame.maxX || pos.y < self.frame.minY || pos.y > self.frame.maxY) {
            return
        }
        self.currentTouchPos = pos
    }
    
    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        let pos = touches.first?.location(in: self)
        handleTouchEnd(pos: pos)
    }
    
    override public func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        let pos = touches.first?.location(in: self)
        handleTouchEnd(pos: pos)
    }
    
    override public func update(_ currentTime: TimeInterval) {
        guard let selectedNode = self.selectedNode else { return }
        guard let currentTouchPos = self.currentTouchPos else { return }
        
        let dt: CGFloat = 1.0 / 60.0
        let vector = CGVector(dx: (currentTouchPos.x - selectedNode.position.x), dy: (currentTouchPos.y - selectedNode.position.y))
        let velocity = CGVector(dx: vector.dx / dt / 3, dy: vector.dy / dt / 3)
        selectedNode.physicsBody?.velocity =  velocity
        
        if isNodeInBottomBarZone() {
            if self.bottomBarNode.children.first(where: { $0.name == selectedNode.name}) != nil {
                selectedNode.run(SKAction.scale(to: 0.7, duration: 0.24))
                selectedNode.physicsBody?.collisionBitMask = 0
                selectedNode.zPosition = 1
            }
        } else {
            selectedNode.run(SKAction.scale(to: 1, duration: 0.24))
            selectedNode.physicsBody?.collisionBitMask = 0xFFFFFFFF
            selectedNode.zPosition = 0
        }
    }
}
