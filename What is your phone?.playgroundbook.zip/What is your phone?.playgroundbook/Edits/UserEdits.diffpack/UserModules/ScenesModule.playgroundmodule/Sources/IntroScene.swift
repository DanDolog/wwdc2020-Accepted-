import SpriteKit
import SupportModule

public class IntroScene: SKScene {
    private var sceneFinishedClosure: (() -> ())?
    var titlesDict = [("Hello!", 1.2),
                      ("How often do you use your phone?" , 2),
                      ("According to statistics 150 times a day!" , 2),
                      ("And it's really cool!" , 2),
                      ("Our phone gave us a bunch of opportunities and deservedly became part of our lives" , 4),
                      ("But what is really your phone?" , 3)]
    
    public init(size: CGSize, sceneFinishedClosure: (() -> ())?) {
        self.sceneFinishedClosure = sceneFinishedClosure
        super.init(size: size)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override public func didMove(to view: SKView) {
        scene?.physicsWorld.gravity = CGVector(dx: 0, dy: 0)
        let borderBody = SKPhysicsBody(edgeLoopFrom: self.frame)
        borderBody.friction = 10
        borderBody.density = 100000
        scene?.physicsBody = borderBody
        
        self.showTitle()
    }
    
    private func showTitle() {
        if !titlesDict.isEmpty {
            guard let title = titlesDict.first?.0 else { return }
            guard let duration = titlesDict.first?.1 else { return }
            let titleNode = SKLabelNode()
            titleNode.alpha = 0
            titleNode.numberOfLines = 0
            titleNode.preferredMaxLayoutWidth = self.size.width / 1.2
            titleNode.verticalAlignmentMode = .center
            
            let attrString = NSMutableAttributedString(string: title)
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.alignment = .center
            let range = NSRange(location: 0, length: title.count)
            attrString.addAttribute(NSAttributedString.Key.paragraphStyle, value: paragraphStyle, range: range)
            attrString.addAttributes([NSAttributedString.Key.foregroundColor : UIColor.white,
                                      NSAttributedString.Key.font : UIFont(name: "HelveticaNeue-Thin", size: 60)!], range: range)
            
            titleNode.attributedText = attrString
            addChild(titleNode)
            let sequence = SKAction.sequence([SKAction.fadeAlpha(to: 1, duration: 0.6),
                                              SKAction.wait(forDuration: TimeInterval(duration)),
                                              SKAction.fadeAlpha(to: 0, duration: 0.6)])
            titleNode.run(sequence, completion: {
                titleNode.removeFromParent()
                self.titlesDict.remove(at: 0)
                self.showTitle()
            })
        } else {
            self.showPhone()
        }
    }
    
    private func showPhone() {
        let phoneNode = SKSpriteNode(imageNamed: "Phone")
        let ratio = phoneNode.size.width / phoneNode.size.height
        phoneNode.size.width = self.size.width * 0.3
        phoneNode.size.height = phoneNode.size.width / ratio
        phoneNode.alpha = 0
        phoneNode.scale(to: CGSize(width: 0.9 * phoneNode.size.width, height: 0.9 * phoneNode.size.height))
        phoneNode.zPosition = 2
        addChild(phoneNode)
        
        let action = SKAction.scale(to: 1, duration: 1)
        action.timingMode = .easeOut
        phoneNode.run(action)
        phoneNode.run(SKAction.fadeAlpha(to: 1, duration: 1), completion: {
            self.showElements(phoneNode: phoneNode)
        })
        
    }
    
    private func showElements(phoneNode: SKNode) {
        guard let elementsArray = JsonParser().getElementsArray() else { return }
        
        let elementSize = CGSize(width: size.width * 0.075, height: size.width * 0.075)
        
        for i in elementsArray.indices {
            let element = elementsArray[i]
            let elementNode = SKShapeNode(rectOf: elementSize, cornerRadius: 20)
            elementNode.name = element.number
            elementNode.fillColor = element.color
            elementNode.strokeColor = SKColor.clear
            
            elementNode.physicsBody = SKPhysicsBody(rectangleOf: elementNode.frame.size)
            elementNode.physicsBody?.allowsRotation = false
            elementNode.physicsBody?.density = 1000
            elementNode.physicsBody?.linearDamping = 9
            elementNode.physicsBody?.restitution = 0
            elementNode.physicsBody?.collisionBitMask = 0
            addChild(elementNode)
            
            let symbolLabel = SKLabelNode(text: element.symbol)
            symbolLabel.verticalAlignmentMode = .center
            symbolLabel.fontName = "AppleSDGothicNeo-Bold"
            elementNode.addChild(symbolLabel)
            
            let numberLabel = SKLabelNode(text: element.number)
            numberLabel.verticalAlignmentMode = .center
            numberLabel.position = CGPoint(x: 0 , y: elementNode.frame.size.height / 2 - 16)
            numberLabel.fontName = "AppleSDGothicNeo-SemiBold"
            numberLabel.fontSize = 16
            elementNode.addChild(numberLabel)
            
            let nameLabel = SKLabelNode(text: element.name)
            nameLabel.verticalAlignmentMode = .center
            nameLabel.position = CGPoint(x: 0 , y: -(elementNode.frame.size.height / 2) + 16)
            nameLabel.fontName = "AppleSDGothicNeo-Bold"
            nameLabel.fontSize = 15
            nameLabel.xScale = 0.78
            elementNode.addChild(nameLabel)
            
            elementNode.xScale = 0.4
            elementNode.yScale = 0.4
            
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(i) * 0.06) {
                elementNode.run(SKAction.scale(to: 1, duration: 0.2))
                elementNode.physicsBody?.applyImpulse(CGVector(dx: cos(Double(Int.random(in: 0..<360))) * 1000000,
                                                               dy: sin(Double(Int.random(in: 0..<360))) * 1000000))
                
                let sequence = SKAction.sequence([SKAction.scale(to: phoneNode.xScale + phoneNode.xScale * 0.03,
                                                                 duration: 0.015),
                                                  SKAction.scale(to: (i == (elementsArray.count - 1)) ?  0 : (1 - (0.0345 * CGFloat(i))),
                                                                 duration: 0.015)])
                phoneNode.run(sequence)
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    elementNode.physicsBody?.collisionBitMask = 0xFFFFFFFF
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    elementNode.physicsBody?.linearDamping = 0
                }
            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + Double(elementsArray.count) * 0.06 + 1.0) {
            self.showLastTitle()
        }
    }
    
    private func showLastTitle() {
        let titleNode = SKLabelNode(text: "Create your phone collecting chemical elements!")
        titleNode.alpha = 0
        titleNode.verticalAlignmentMode = .center
        titleNode.fontSize = 45
        
        let tapAnywhereNode = SKLabelNode(text: "Tap anywhere to start")
        tapAnywhereNode.alpha = 0
        tapAnywhereNode.verticalAlignmentMode = .center
        tapAnywhereNode.fontSize = 30
        tapAnywhereNode.position.y = titleNode.position.y - 50
        
        let gravityField1 = SKFieldNode.linearGravityField(withVector: vector_float3(x: 0, y: 0.2, z: 0))
        let gravityField2 = SKFieldNode.linearGravityField(withVector: vector_float3(x: 0, y: -0.2, z: 0))
        
        let regionSize = CGSize(width: self.size.width, height: 90)
        gravityField1.region = SKRegion(size: regionSize)
        gravityField2.region = SKRegion(size: regionSize)
        gravityField1.position.y = regionSize.height / 2 - 20.0
        gravityField2.position.y = -regionSize.height / 2 - 20.0
        
        addChild(gravityField1)
        addChild(gravityField2)
        addChild(tapAnywhereNode)
        addChild(titleNode)
        
        let sequence = SKAction.sequence([SKAction.fadeAlpha(to: 1, duration: 1),
                                          SKAction.wait(forDuration: 0.5),
                                          SKAction.fadeAlpha(to: 0.2, duration: 1),
                                          SKAction.wait(forDuration: 0)])
        tapAnywhereNode.run(SKAction.repeatForever(sequence))
        titleNode.run(SKAction.fadeIn(withDuration: 1.4))
    }
    
    private func touchEndedHandle(touchPos: CGPoint) {
        let gravityField = SKFieldNode.radialGravityField()
        
        gravityField.region = SKRegion(size: self.size)
        gravityField.strength = -100
        gravityField.position = touchPos
        
        addChild(gravityField)
        
        self.physicsBody = nil
        
        self.run(SKAction.fadeOut(withDuration: 0.6), completion: {
            self.sceneFinishedClosure?()
        })
    }
    
    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let location = touches.first?.location(in: self) else { return }
        touchEndedHandle(touchPos: location)
    }
    
    override public func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let location = touches.first?.location(in: self) else { return }
        touchEndedHandle(touchPos: location)
    }
}

