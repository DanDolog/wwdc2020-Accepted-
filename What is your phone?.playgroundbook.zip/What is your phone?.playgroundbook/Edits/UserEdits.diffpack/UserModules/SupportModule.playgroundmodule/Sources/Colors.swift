//#-hidden-code
import SpriteKit

public struct Colors {
    static let purple = SKColor(red: 91/255, green: 54/255, blue: 144/255, alpha: 100)
    static let pink = SKColor(red: 255/255, green: 17/255, blue: 107/255, alpha: 100)
    static let blue = SKColor(red: 29/255, green: 62/255, blue: 151/255, alpha: 100)
    static let orange = SKColor(red: 255/255, green: 117/255, blue: 29/255, alpha: 100)
    static let yellow = SKColor(red: 255/255, green: 191/255, blue: 2/255, alpha: 100)
    static let cyan = SKColor(red: 18/255, green: 201/255, blue: 255/255, alpha: 100)
    static let green = SKColor(red: 62/255, green: 171/255, blue: 171/255, alpha: 100)
    static let red = SKColor(red: 220/255, green: 25/255, blue: 20/255, alpha: 100)
    static let lightGreen = SKColor(red: 81/255, green: 208/255, blue: 54/255, alpha: 100)
}
//#-end-hidden-code
