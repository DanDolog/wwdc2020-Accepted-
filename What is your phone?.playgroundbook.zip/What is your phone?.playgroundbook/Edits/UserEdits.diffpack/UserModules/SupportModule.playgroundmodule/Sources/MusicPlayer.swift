import AVFoundation

public class MusicManager {
    
    public static let shared = MusicManager()
    private var player: AVAudioPlayer?
    
    private init() { }
    
    public func playMainTheme() {
        guard let url = Bundle.main.url(forResource: "MainTheme", withExtension: "mp3") else { return }
        
        do {
            player = try AVAudioPlayer(contentsOf: url)
            guard let player = player else { return }
            
            player.volume = 0.20
            player.prepareToPlay()
            player.play()
            player.numberOfLoops = -1
            
        } catch let sessionError {
            print(sessionError)
        }
    }
}
