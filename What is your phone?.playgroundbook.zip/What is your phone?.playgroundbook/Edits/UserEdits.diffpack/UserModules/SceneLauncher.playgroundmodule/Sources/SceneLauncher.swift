import UIKit
import SpriteKit
import SupportModule
import ScenesModule

public class SceneLauncher {
    private var screenSize: CGSize
    private var skView: SKView
    private let scenesModelsArray = JsonParser().getSceneModelsArray()
    private var finishedSceneCounter = -2
    private var sceneFinishedClosure: (() -> ())?
    
    public init(skView: SKView, screenSize: CGSize) {
        self.skView = skView
        self.screenSize = screenSize
        
        self.sceneFinishedClosure = {
            self.finishedSceneCounter += 1
            self.launchScene()
        }
    }
    
    public func launchScene() {
        var skScene = SKScene()
        switch finishedSceneCounter {
        case -2:
            skScene = StartScene(size: self.screenSize, sceneFinishedClosure: sceneFinishedClosure)
        case -1:
            skScene = IntroScene(size: self.screenSize, sceneFinishedClosure: sceneFinishedClosure)
        case 4:
            skScene = FinalScene(size: self.screenSize, sceneFinishedClosure: sceneFinishedClosure)
        default:
            guard let scenesModelsArray = scenesModelsArray else { return }
            skScene = GameScene(size: self.screenSize,
                                model: scenesModelsArray[finishedSceneCounter],
                                sceneFinishedClosure: sceneFinishedClosure)
        }
        
        skScene.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        skScene.scaleMode = .aspectFit
        
        self.skView.presentScene(skScene)
        self.skView.ignoresSiblingOrder = true
        self.skView.showsFPS = true
        self.skView.showsNodeCount = true
    }
}
