import Foundation
import SpriteKit

public struct ElementModel: Decodable {
    public let number: String
    public let name: String
    public let symbol: String
    public let color: SKColor
    
    
    enum CodingKeys: CodingKey {
        case number
        case name
        case symbol
        case color
    }
    
    public init (from decoder: Decoder) throws {
        let value = try decoder.container(keyedBy: CodingKeys.self)
        self.number = try value.decode(String.self, forKey: .number)
        self.name = try value.decode(String.self, forKey: .name)
        self.symbol = try value.decode(String.self, forKey: .symbol)
        
        let color = try value.decode(String.self, forKey: .color)
        switch color {
        case "purple":
            self.color = Colors.purple
        case "pink":
            self.color = Colors.pink
        case "blue":
            self.color = Colors.blue
        case "orange":
            self.color = Colors.orange
        case "yellow":
            self.color = Colors.yellow
        case "cyan":
            self.color = Colors.cyan
        case "green":
            self.color = Colors.green
        case "red":
            self.color = Colors.red
        case "lightGreen":
            self.color = Colors.lightGreen
        default:
            self.color = SKColor.darkGray
        }
    }
}

