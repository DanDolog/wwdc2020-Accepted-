import Foundation
import SpriteKit

public struct ElementsGroupModel: Decodable {
    public let groupName: String
    public let groupColor: SKColor
    
    
    enum CodingKeys: CodingKey {
        case groupName
        case groupColor
    }
    
    public init (from decoder: Decoder) throws {
        let value = try decoder.container(keyedBy: CodingKeys.self)
        self.groupName = try value.decode(String.self, forKey: .groupName)
        let color = try value.decode(String.self, forKey: .groupColor)
        switch color {
        case "purple":
            self.groupColor = Colors.purple
        case "pink":
            self.groupColor = Colors.pink
        case "blue":
            self.groupColor = Colors.blue
        case "orange":
            self.groupColor = Colors.orange
        case "yellow":
            self.groupColor = Colors.yellow
        case "cyan":
            self.groupColor = Colors.cyan
        case "green":
            self.groupColor = Colors.green
        case "red":
            self.groupColor = Colors.red
        case "lightGreen":
            self.groupColor = Colors.lightGreen
        default:
            self.groupColor = SKColor.darkGray
        }
    }
}
