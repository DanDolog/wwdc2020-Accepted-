import SpriteKit
import SupportModule

public class FinalScene: SKScene {
    private var sceneFinishedClosure: (() -> ())?
    private var elementsArray = [SKNode]()
    
    public init(size: CGSize, sceneFinishedClosure: (() -> ())?) {
        self.sceneFinishedClosure = sceneFinishedClosure
        super.init(size: size)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override public func didMove(to view: SKView) {
        scene?.physicsWorld.gravity = CGVector(dx: 0, dy: 0)
        let borderBody = SKPhysicsBody(edgeLoopFrom: self.frame)
        borderBody.friction = 0
        borderBody.density = 100000
        scene?.physicsBody = borderBody
        
        addTitle()
    }
    
    private func addTitle() {
        let titleNode = SKLabelNode(text: "Congratulations!")
        titleNode.alpha = 0
        titleNode.verticalAlignmentMode = .center
        titleNode.fontSize = 80
        titleNode.fontName = "HelveticaNeue-Thin"
        addChild(titleNode)
        
        let sequence = SKAction.sequence([SKAction.fadeAlpha(to: 1, duration: 0.6),
                                          SKAction.wait(forDuration: 2),
                                          SKAction.fadeAlpha(to: 0, duration: 0.6)])
        
        titleNode.run(sequence, completion: {
            let thanksNode = SKLabelNode(text: "Thanks for playing!")
            thanksNode.alpha = 0
            thanksNode.verticalAlignmentMode = .center
            thanksNode.fontSize = 45
            thanksNode.fontName = "HelveticaNeue-Thin"
            thanksNode.position.y = self.frame.maxY - 60
            
            let titleNode = SKLabelNode(text: "Now you know your phone better!")
            titleNode.alpha = 0
            titleNode.verticalAlignmentMode = .center
            titleNode.fontSize = 60
            titleNode.fontName = "HelveticaNeue-Thin"
            
            let tapAnywhereNode = SKLabelNode(text: "Tap anywhere to play again")
            tapAnywhereNode.alpha = 0
            tapAnywhereNode.verticalAlignmentMode = .center
            tapAnywhereNode.fontSize = 30
            tapAnywhereNode.position.y = titleNode.position.y - 50
            tapAnywhereNode.fontName = "HelveticaNeue-Thin"
            
            let wwdcNode = SKLabelNode(text: "WWDC 2020")
            wwdcNode.alpha = 0
            wwdcNode.verticalAlignmentMode = .center
            wwdcNode.fontSize = 30
            wwdcNode.fontName = "HelveticaNeue-Thin"
            wwdcNode.position.y = self.frame.minY + 50
            
            self.addChild(tapAnywhereNode)
            self.addChild(titleNode)
            self.addChild(wwdcNode)
            self.addChild(thanksNode)
            
            let sequence = SKAction.sequence([SKAction.fadeAlpha(to: 1, duration: 1),
                                              SKAction.wait(forDuration: 0.5),
                                              SKAction.fadeAlpha(to: 0.2, duration: 1),
                                              SKAction.wait(forDuration: 0)])
            
            tapAnywhereNode.run(SKAction.repeatForever(sequence))
            titleNode.run(SKAction.fadeIn(withDuration: 1.4))
            wwdcNode.run(SKAction.fadeIn(withDuration: 1.4))
            thanksNode.run(SKAction.fadeIn(withDuration: 1.4))
            self.showElements()
        })
    }
    
    private func showElements() {
        let elementsNumbersArray = ["3", "8", "65", "14", "79", "33", "35", "12"]
        guard let elementsArray = JsonParser().getElementsArray()?.filter({ elementsNumbersArray.contains($0.number)}) else { return }
        
        let elementSize = CGSize(width: size.width * 0.075, height: size.width * 0.075)
        
        for i in elementsArray.indices {
            let element = elementsArray[i]
            let elementNode = SKShapeNode(rectOf: elementSize, cornerRadius: 20)
            elementNode.name = element.number
            elementNode.fillColor = element.color
            elementNode.strokeColor = SKColor.clear
            
            elementNode.physicsBody = SKPhysicsBody(rectangleOf: elementNode.frame.size)
            elementNode.physicsBody?.allowsRotation = false
            elementNode.physicsBody?.density = 1000
            elementNode.physicsBody?.restitution = 0
            addChild(elementNode)
            
            let symbolLabel = SKLabelNode(text: element.symbol)
            symbolLabel.verticalAlignmentMode = .center
            symbolLabel.fontName = "AppleSDGothicNeo-Bold"
            elementNode.addChild(symbolLabel)
            
            let numberLabel = SKLabelNode(text: element.number)
            numberLabel.verticalAlignmentMode = .center
            numberLabel.position = CGPoint(x: 0 , y: elementNode.frame.size.height / 2 - 16)
            numberLabel.fontName = "AppleSDGothicNeo-SemiBold"
            numberLabel.fontSize = 16
            elementNode.addChild(numberLabel)
            
            let nameLabel = SKLabelNode(text: element.name)
            nameLabel.verticalAlignmentMode = .center
            nameLabel.position = CGPoint(x: 0 , y: -(elementNode.frame.size.height / 2) + 16)
            nameLabel.fontName = "AppleSDGothicNeo-Bold"
            nameLabel.fontSize = 15
            nameLabel.xScale = 0.78
            elementNode.addChild(nameLabel)
            
            elementNode.alpha = 0
            elementNode.run(SKAction.fadeAlpha(to: 0.6, duration: 1))
            elementNode.position = CGPoint(x: Int.random(in: -(Int(self.size.width) / 2)..<(Int(self.size.width) / 2 - Int(elementSize.width))),
                                           y: Int.random(in: Int(self.frame.minY + elementSize.width)..<(Int(self.size.height) / 2 - Int(elementSize.width))))
            
            self.elementsArray.append(elementNode)
        }
        impulse()
    }
    
    private func impulse() {
        self.elementsArray.forEach({
            $0.physicsBody?.applyImpulse(CGVector(dx: cos(Double(Int.random(in: 0..<360))) * 1000,
                                                  dy: sin(Double(Int.random(in: 0..<360))) * 1000))
        })
        
        Timer.scheduledTimer(withTimeInterval: 0.01, repeats: true) { timer in
            self.impulse()
            timer.invalidate()
        }
    }
    
    private func touchEndedHandle(touchPos: CGPoint) {
        let gravityField = SKFieldNode.radialGravityField()
        
        gravityField.region = SKRegion(size: self.size)
        gravityField.strength = -100
        gravityField.position = touchPos
        
        addChild(gravityField)
        
        self.physicsBody = nil
        
        self.run(SKAction.fadeOut(withDuration: 0.6), completion: {
            self.sceneFinishedClosure?()
        })
    }
    
    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let location = touches.first?.location(in: self) else { return }
        touchEndedHandle(touchPos: location)
    }
    
    override public func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let location = touches.first?.location(in: self) else { return }
        touchEndedHandle(touchPos: location)
    }
}

